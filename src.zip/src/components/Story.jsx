import React from 'react'

const Story = () => {
  return (
    <div>
      <div className='fle'>
        <div>
            <h1>Our Story</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus, excepturi.</p>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Autem asperiores laboriosam harum aliquid odit fugit rerum illo, atque repudiandae consequatur pariatur tempore </p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque, odio.</p>
        </div>
        <div>
            <div></div>
            <div><img src="" alt="" /></div>
            <div></div>
        </div>
      </div>
    </div>
  )
}

export default Story
