import React from 'react'
import Featurecard from './props/Featurecard'

const Feature = () => {
    return (
        <div className='px-4'>
        <Featurecard />
      
    </div>
  )
}

export default Feature
